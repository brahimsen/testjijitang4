
$(document).ready(function() {
	
			 $(".profile-follow").click(function(){
						$(".profile-page-unfollowed,.profile-page-followed",this).toggleClass("hide-follow-check");
					
						
								
				});
	
	

});