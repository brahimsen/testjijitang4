 $(document).ready(function() {
		
					
						$(".arrow-down").hide();
				$(".arrow-holder").click(function(){
					$(".arrow-up,.arrow-down",this).toggle();
					
				});
				
					
				});
 $(document).ready(function() {
	 
	 	
				
			
				$(".email-arrow-up").click(function(){
					$("#Email-send-Modal").modal('show');
					
						
								
			
				
				
			});
				});