
$(document).ready(function() {
	
			 $(".project-follow").click(function(){
						$(".project-page-unfollowed,.project-page-followed",this).toggleClass("hide-follow-check");
					
						
								
				});
	
	

});

