 $(document).ready(function() {
	 
	 $(".unfollow-btn").hide();
	 $(".follow-user-btn-holder").click(function(){
						$(".follow-btn,.unfollow-btn",this).toggle(
						
						
						);
					
						
								
				});
				
			});