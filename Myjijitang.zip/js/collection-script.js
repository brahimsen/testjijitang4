
$(document).ready(function() {
	
			 $(".collection-follow").click(function(){
						$(".collection-page-unfollowed,.collection-page-followed",this).toggleClass("hide-follow-check");
					
						
								
				});
				
				
				
	
	

});