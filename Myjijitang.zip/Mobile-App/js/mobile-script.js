    $(document).ready(function(){
			
		       var myDiv = $('.article-update-text');
				myDiv.text(myDiv.text().substring(0,110) + '...')
        
        });
        